<?php 
include "config.php";

if(isset($_GET['delete_id']))
{
    $id = $_GET['delete_id'];
    $sql = "DELETE FROM usuario WHERE id=$id";
    $conexao->query($sql);
    header("location: index.php");
}

?>
<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Datatables com PHP</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" href="css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
    <div class="main">
        <a href="user.php" class="btn-blue">Novo</a>
        <h3 class="text-center">Lista de usuários</h3>
        <table class="striped" id="example">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Telefone</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php $consulta = $conexao->query("SELECT * FROM usuario"); 
                  while($row = $consulta->fetch()) { 
            ?>
                <tr>
                <td><?= $row['nome']; ?></td>
                <td><?= $row['email']; ?></td>
                <td><?= $row['telefone']; ?></td>
                <td colspan="2">
                <a class="btn-green" href="edit_user.php?edit_id=<?= $row['id']; ?>">Editar</a>
                <a class="btn-red" href="?delete_id=<?= $row['id']; ?>">Excluir</a>
                </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
    </body>
    <script src="js/jquery-3.5.1.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
</html>
<script>
$(document).ready(function() {
    $('#example').DataTable(
    {
        "oLanguage": {
        "sLengthMenu": "Mostrar _MENU_ registros por página",
        "sZeroRecords": "Nenhum registro encontrado",
        "sInfo": "Mostrando _START_ a _END_ de _TOTAL_ registro(s)",
        "sInfoEmpty": "Mostrando 0 a 0 de 0 registros",
        "sInfoFiltered": "(filtrando de _MAX_ registros)",
        "sSearch": "Pesquisar",
        "sProcessing": "Processando",
        "oPaginate": {
            "sFirst": "Início",
            "sPrevious": "Anterior",
            "sNext": "Próximo",
            "sLast": "Último",
        }
      }
    }
    );
} );
</script>
