<?php 

try
{
    $conexao = new PDO("mysql:host=localhost;dbname=datatable_pdo", "root", "");
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conexao->exec("SET NAMES UTF8");
}
catch(PDOException $e)
{
    echo "Erro de conexão:<br>" . $e->getMessage();
}

?>
