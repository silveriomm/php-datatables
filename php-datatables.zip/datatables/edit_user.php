<?php 
include "config.php";

$id = $_GET['edit_id'];

$sql = "SELECT * FROM usuario WHERE id=$id";
$query = $conexao->prepare($sql);
$query->execute(array(':id' => $id));

while($row = $query->fetch(PDO::FETCH_ASSOC))
{
    $id = $id;
    $nome = $row['nome'];
    $email = $row['email'];
    $telefone = $row['telefone'];
}

if(isset($_POST['update']))
{
    $id = $_GET['edit_id'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];

    $sql = "UPDATE usuario SET nome='$nome', email='$email', telefone='$telefone' WHERE id=$id";

    $conexao->query($sql);
    header("location: index.php");
}

?>
<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Datatables com PHP</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" href="css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
    <div class="main">
        <a href="index.php" class="btn-blue">Voltar</a>
        <h3 class="text-center">Editar usuário</h3>
        <div class="section">
        <form action="" method="post">
            <div class="form-group">
                <label>Nome</label>
                <input class="form-control" type="text" name="nome" value="<?= $nome ?>" required autofocus>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input class="form-control" type="text" name="email" value="<?= $email ?>" required>
            </div>
            <div class="form-group">
                <label>Telefone</label>
                <input class="form-control" type="text" name="telefone" value="<?= $telefone ?>" required>
            </div>
            <div>
                <input class="btn-green" type="submit" name="update" value="Salvar">
            </div>
        </form>
        </div>
    </div>
    </body>
    <script src="js/jquery-3.5.1.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
</html>
<script>
$(document).ready(function() {
    $('#example').DataTable(
    {
        "oLanguage": {
        "sLengthMenu": "Mostrar _MENU_ registros por página",
        "sZeroRecords": "Nenhum registro encontrado",
        "sInfo": "Mostrando _START_ a _END_ de _TOTAL_ registro(s)",
        "sInfoEmpty": "Mostrando 0 a 0 de 0 registros",
        "sInfoFiltered": "(filtrando de _MAX_ registros)",
        "sSearch": "Pesquisar",
        "sProcessing": "Processando",
        "oPaginate": {
            "sFirst": "Início",
            "sPrevious": "Anterior",
            "sNext": "Próximo",
            "sLast": "Último",
        }
      }
    }
    );
} );
</script>
